#include <linux/version.h>
#define RELEASE "Linux NET-3 Base Utilities\nSource: net-tools 1.32-alpha net-tools@lina.inka.de (Bernd Eckenfels)\nKernelsource: " UTS_RELEASE
#define Maintainer "net-tools@lina.inka.de (Bernd Eckenfels)"
