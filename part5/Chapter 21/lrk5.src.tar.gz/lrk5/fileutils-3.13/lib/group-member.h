#ifndef _group_member_h_
#define _group_member_h_ 1

int
  group_member ();

#endif /* _group_member_h_ */
