#ifndef GROUP_MEMBER_H_
# define GROUP_MEMBER_H_ 1

int
  group_member ();

#endif /* GROUP_MEMBER_H_ */
